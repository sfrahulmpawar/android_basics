package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CalculatorActivity extends AppCompatActivity {
    EditText firstEdit, secondEdit;
    Button addButton,subButton,mulButton,divButton;
    TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);
        firstEdit = (EditText) findViewById(R.id.firstEdit);
        secondEdit = (EditText) findViewById(R.id.secondEdit);
        addButton = (Button) findViewById(R.id.addButton);
        subButton = (Button) findViewById(R.id.subButton);
        mulButton = (Button) findViewById(R.id.mulButton);
        divButton = (Button) findViewById(R.id.divButton);
        resultText = (TextView) findViewById(R.id.resultText);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String num1 = firstEdit.getText().toString();
                String num2 = secondEdit.getText().toString();
                int a = Integer.parseInt(num1);
                int b = Integer.parseInt(num2);
                int sum = a+b;
                resultText.setText("Result is: " + sum);
            }
        });
        subButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String num1 = firstEdit.getText().toString();
                String num2 = secondEdit.getText().toString();
                int a = Integer.parseInt(num1);
                int b = Integer.parseInt(num2);
                int sum = a-b;
                resultText.setText("Result is: " + sum);
            }
        });
        mulButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String num1 = firstEdit.getText().toString();
                String num2 = secondEdit.getText().toString();
                int a = Integer.parseInt(num1);
                int b = Integer.parseInt(num2);
                int sum = a*b;
                resultText.setText("Result is: " + sum);
            }
        });
        divButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String num1 = firstEdit.getText().toString();
                String num2 = secondEdit.getText().toString();
                int a = Integer.parseInt(num1);
                int b = Integer.parseInt(num2);
                int sum = a/b;
                resultText.setText("Result is: " + sum);
            }
        });
    }
}
